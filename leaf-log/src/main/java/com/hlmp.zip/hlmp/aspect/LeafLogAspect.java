package com.hlmp.aspect;


import java.io.Serializable;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;
import javax.sound.midi.Sequence;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.core.annotation.Order;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSONObject;
import com.haier.cosmomi.plugins.utils.ThreadPoolUtil;
import com.hlmp.annotation.LeafLog;
import com.hlmp.annotation.LeafLogOperateType;
import com.hlmp.constant.LeafLogConstant;



/**
 * 语义化业务日志切面类
 * @description 标记业务处理方法，将业务日志入库
 * @author Leaf Xu
 * @date 2018-8-27 10:46:25
 */

@Aspect
@Order(-4)
@Component
public class LeafLogAspect {

	/**
	 * 注入Service用于把日志保存数据库
	 */
//	@Autowired
//	private SystemLogService systemLogService;
	/**
	 * 用于获取用户信息
	 */
//	@Autowired
//	private SystemManager systemManager;
	
	private final static Logger logger = LoggerFactory.getLogger(LeafLogAspect.class);
	
	
	/**
	 * Controller层切点
	 */
	@Pointcut("execution (* com.haier.cosmomi.boot.controller..*.*(..))")
	public void controllerAspect() {
	}

	/**
	 * 环绕切面，记录操作日志入库
	 */
	@Around(value = "controllerAspect() && @annotation(leafLog)", argNames = "pjp,leafLog")
	public Object around(ProceedingJoinPoint pjp, com.hlmp.annotation.LeafLog leafLog) throws Throwable {
		Object result = null;
		Throwable error = null;
		try {
			result = pjp.proceed();
			return result;
		} catch (Throwable e) {
			error = e;
			e.printStackTrace();
			throw e;
		} finally {
			handlerLeafLog(pjp, leafLog, result, error);
		}
			
	}

	
	/**
	 * 业务日志内容处理，入库处理
	 * @param pjp 
	 * @param leafLog 
	 * @param result 
	 * @param error 
	 */
	private void handlerLeafLog(ProceedingJoinPoint pjp, LeafLog leafLog, Object result, Throwable error) {
		try {
			SystemLog log = new SystemLog();
			
			//获取登录用户信息
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			String userId = null;
			String userName = null;
			String userFullName = null;
//			Authentication authentication = SecurityUtil.getAuthentication();
//			if (!(authentication instanceof AnonymousAuthenticationToken)) {
//				userId = systemManager.getUserId();
//				userName = systemManager.getUsername();
//				userFullName = systemManager.getAuthUser().getName();
//			}
			String targetName = pjp.getTarget().getClass().getName();
			String methodName = pjp.getSignature().getName();
			
//			log.setLogOperateParams(getMethodParamJson(pjp));
//			log.setLogOperateMethod(targetName+"."+methodName);
//			
//			log.setLogRequestUri(request.getRequestURI());
//			log.setLogRemoteAddr(request.getRemoteAddr());
//			log.setCreateBy(userId);
//			log.setCreateDate(Calendar.getInstance().getTime());
//			log.setId(Sequence.getUUID32());
			// *========数据库日志=========*//
//			log.setCreateDate(new Date());
			
			//---------- 注解逻辑处理 开始-----------
			
			//通过spring工具类获取leafLog注解参数（二次加工）
			MethodSignature methodSignature = (MethodSignature) pjp.getSignature();
			Method method = methodSignature.getMethod();
			LeafLog springLeafLog = AnnotationUtils.findAnnotation(method, LeafLog.class);
			
			//leafLog 操作类型 获取
			LeafLogOperateType opeType = springLeafLog.operationType();
			
//			log.setLogType(opeType.getValue());
			//设置日志内容标题
			String opeName = springLeafLog.operationName();
			String titleDesc =MessageFormat.format(
					LeafLogConstant.OPERATE_TITLE_FORMAT, 
					userId,
					"username",
					opeName);
			log.setLogTitle(titleDesc);
			//----------- 注解逻辑处理结束 ----------
			
			// 保存数据库
			ExecutorService exec = ThreadPoolUtil.getThreadPool();
			exec.execute(()-> {
//				systemLogService.insert(log);
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("业务日志处理异常---------{}", e.getMessage());
		}
	}
	
	


	
	/**
	 * 将目标方法参数 装配 为json对象字符串返回
	 * @param joinPoint
	 * @return
	 */
	private static String getMethodParamJson(JoinPoint joinPoint) {
		// 获取用户请求方法的参数并序列化为JSON格式字符串
		JSONObject json = new JSONObject();
		String [] parameterNames = ((MethodSignature)joinPoint.getSignature()).getParameterNames();
		Object [] args = joinPoint.getArgs();
		
		if (args != null && args.length > 0) {
			for(int i=0;i<args.length;i++) {
				Object arg = args[i];
				if(arg instanceof Serializable) {
					json.put(parameterNames[i], arg);
				}
			}
		}
		return json.toJSONString();
	}
	
}

class ThreadPoolUtil {
	
	private  static ExecutorService executor ;
	
	public static ExecutorService getThreadPool(){
		if(executor == null) {
			synchronized (ThreadPoolUtil.class) {
				if(executor == null) {
					executor = Executors.newFixedThreadPool(1000);
				}
			}
		}
		return  executor;
	}
	
}